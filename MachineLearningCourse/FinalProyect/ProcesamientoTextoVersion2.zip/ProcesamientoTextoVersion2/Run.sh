#Tokenizar texto
python Tokenizar.py

#Lematizar "Quitar cerradas y signos"
python3 Lemas2.py

#Stemming
python3 Stemming.py

python3 ObtenVoc.py Espanol-Categorias
python3 ObtenVoc.py Espanol-Tokens
python3 ObtenVoc.py Ingles-Sttemming
python3 ObtenVoc.py Espanol-Lemas
python3 ObtenVoc.py Ingles-Categorias
python3 ObtenVoc.py Ingles-Tokens
python3 ObtenVoc.py Espanol-Sttemming
python3 ObtenVoc.py Ingles-Lemas

python3 GeneraCSV.py Espanol-Categorias
python3 GeneraCSV.py Espanol-Tokens
python3 GeneraCSV.py Ingles-Sttemming
python3 GeneraCSV.py Espanol-Lemas
python3 GeneraCSV.py Ingles-Categorias
python3 GeneraCSV.py Ingles-Tokens
python3 GeneraCSV.py Espanol-Sttemming
python3 GeneraCSV.py Ingles-Lemas


